# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import *
from .models import *
# Create your views here.
from django.http import HttpResponse
from django.template import RequestContext, loader
from models import BookInfo

def index(request):
    bookList = BookInfo.objects.all()
    template = loader.get_template('../book/index.html')
    context = RequestContext(request, {'booklist':bookList})

    return HttpResponse(template.render(context))

def detail(request, id):
    book = BookInfo.objects.get(pk=id)
    template = loader.get_template('../book/detail.html')
    context = RequestContext(request, {'book':book})

    return HttpResponse(template.render(context))